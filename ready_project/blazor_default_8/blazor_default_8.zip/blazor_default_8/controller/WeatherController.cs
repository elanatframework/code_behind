using CodeBehind;

public partial class WeatherController : CodeBehindController
{
    public void PageLoad(HttpContext context)
    {
        WebForms form = new WebForms();

        form.SetVisible("<table>", false);
        form.Delete("Loading");
        form.AssignDelay(.5f);
        form.SetVisible("<table>", true);
        form.AssignDelay(.5f);

        Write(form.ExportToWebFormsTag());

        OnInitialized();
    }

    private void OnInitialized()
    {
        WeatherModel model = new WeatherModel();

        var startDate = DateOnly.FromDateTime(DateTime.Now);
        var summaries = new[] { "Freezing", "Bracing", "Chilly", "Cool", "Mild", "Warm", "Balmy", "Hot", "Sweltering", "Scorching" };
        model.Forecasts = Enumerable.Range(1, 5).Select(index => new WeatherForecast
        {
            Date = startDate.AddDays(index),
            TemperatureC = Random.Shared.Next(-20, 55),
            Summary = summaries[Random.Shared.Next(summaries.Length)]
        }).ToArray();

        View(model);
    }
}