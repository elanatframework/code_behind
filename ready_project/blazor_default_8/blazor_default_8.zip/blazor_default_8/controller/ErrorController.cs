using CodeBehind;
using Microsoft.AspNetCore.Components;
using System.Diagnostics;

public partial class ErrorController : CodeBehindController
{
    [CascadingParameter]
    private HttpContext? HttpContext { get; set; }
    private string? RequestId { get; set; }
    private bool ShowRequestId => !string.IsNullOrEmpty(RequestId);
    protected void OnInitialized() => RequestId = Activity.Current?.Id ?? HttpContext?.TraceIdentifier;

    public void PageLoad(HttpContext context)
    {
        ErrorModel model = new ErrorModel();

        model.RequestId = RequestId;
        model.ShowRequestId = ShowRequestId;

        View(model);
    }
}