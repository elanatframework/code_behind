using CodeBehind;
using System.Reflection;

public partial class CounterController : CodeBehindController
{
    public void PageLoad(HttpContext context)
    {
        if (context.Request.Form["Button"].Has())
            Button_Click();
    }

    private void Button_Click()
    {
        WebForms form = new WebForms();

        form.IncreaseValue("(Hidden)", 1);
        form.SaveValue("(Hidden)");
        form.SetText("<span>-1", Fetch.Saved());
        form.SetCache(31536000); // One Year

        Control(form, true);
    }
}