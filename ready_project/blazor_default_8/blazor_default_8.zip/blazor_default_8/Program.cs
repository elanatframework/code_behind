var builder = WebApplication.CreateBuilder(args);

var app = builder.Build();

SetCodeBehind.CodeBehindCompiler.Initialization(!app.Environment.IsDevelopment());

app.UseHttpsRedirection();

app.UseStaticFiles();

app.UseCodeBehind(true);

app.Run();