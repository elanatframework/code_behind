public partial class ErrorModel
{
    public bool ShowRequestId { get; set; }
    public string RequestId { get; set; }
}