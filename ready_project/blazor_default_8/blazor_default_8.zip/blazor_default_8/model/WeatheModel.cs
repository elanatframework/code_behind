public class WeatherModel
{
    public WeatherForecast[]? Forecasts;
}